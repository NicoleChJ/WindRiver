import { calculaISV, Prodcuto } from "./06-desestructuracion";

const carritocompras: Prodcuto[]=[
    {
        desc:"Tel 1",
        precio: 100
    },
    {
        desc:"Tel 2",
        precio: 200
    }
];

const [total,isv]= calculaISV(carritocompras); //Ojo al ejecutar el archivo se ejecuta todo el otro .ts

console.log("Total", total)
console.log("ISV",isv)
