function queTipoSoy <T>(argumento: T){
    return argumento;
}

let soyString= queTipoSoy("Hola Mundo");
let soynum= queTipoSoy(3);

