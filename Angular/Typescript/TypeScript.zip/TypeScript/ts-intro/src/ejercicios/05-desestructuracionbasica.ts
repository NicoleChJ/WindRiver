/**** Funciones ****/

interface Reproductor{
    volumen: number,
    segundo: number ,
    cancion: string,
    detalles:  Detalles
}

interface Detalles{
    autor: string;
    anio: number;
}

const reproductor: Reproductor={
    volumen:90,
    segundo:36,
    cancion:"Mess",
    detalles:{
        autor:"Ed Sheeran",
        anio:2015
    }

}

const{volumen,segundo,detalles:{autor:nombreautor}}=reproductor; /* obtiene los elementos como constantes */


//console.log("El volumen actual:",volumen) /* Se esta usando la desestructuracion*/
//console.log("El segundo actual:",segundo)
//console.log("El autor actual:",nombreautor)
//console.log("La cancion actual:",reproductor.cancion)

const dbz: string[]=["Goku", "Vegeta", "trunks"];

const [p1,p2,p3]=dbz; // Si no quiero guardar p1 y p2, solo dejo comas para dejar el espacio
// const [,,p3]=dbz; 
console.log("Personaje 1",p3)
