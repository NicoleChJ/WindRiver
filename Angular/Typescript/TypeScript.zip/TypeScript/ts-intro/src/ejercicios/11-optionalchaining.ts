interface Pasajero{
    nombre:string;
    hijos?: string[]
}

const pasajero1:Pasajero= {
    nombre:"Fernando"
}

const pasajero2: Pasajero={
    nombre: "Melissa",
    hijos:["Natalia","Gabriel"]
}

function imprimirHijos(pasajero:Pasajero): void{
    //encadenamiento opcional o secure operator
    const cuantosHijos= pasajero.hijos?.length || 0; //? significa Que intente ver la variable, or || cero
    console.log(cuantosHijos)
}

imprimirHijos(pasajero1);