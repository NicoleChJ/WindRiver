/****  ****/
export interface Prodcuto{
    desc: string;
    precio: number;

}

const telefono: Prodcuto ={
    desc:"Nokia A1",
    precio: 150
}

const tableta: Prodcuto ={
    desc:"ipad air ",
    precio: 350
}
export  function calculaISV(productos:Prodcuto[]): [number, number] {
    let total=0;
    productos.forEach(({precio})=>{ // En vez de escribir producto y abajo seria producto.precio
        total+= precio
    })
    return [total, total * 0.15]
}

const articulos=[telefono, tableta];
const [total,isv]= calculaISV(articulos)

console.log("ISV", isv)
console.log("total", total)
