/**** Funciones ****/


function sumar (a:number, b:number): number{ /*entra dos int y sale un int */
    return a+b; }


function multiplicar (a:number, b?:number, base:number=2): number{ 
    /*primero argumentos obligatorios,opcionales y luego los que tienen un valor por defecto*/
    return a*base; 
}

const resultado= sumar(10,20)
const resultado1= multiplicar(5)
const resultado2= multiplicar(5,0,10)  /*para modificar el argumento de la base */
console.log(resultado, resultado1,resultado2)

interface personajeLOR{
    nombre: string;
    pv: number;
    mostrarHP:() => void /*define función*/
}
function curar (personaje:personajeLOR, curarX:number): void{ /*para no retornar nada*/
    personaje.pv += curarX;
}

const nuevoPersonaje: personajeLOR={
    nombre: "Strider",
    pv:50,
    mostrarHP(){console.log("Puntos de vida", this.pv)}
}

curar(nuevoPersonaje,20);

nuevoPersonaje.mostrarHP();



