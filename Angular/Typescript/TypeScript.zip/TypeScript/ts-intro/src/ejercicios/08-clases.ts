//Metodo 1
/*
class Heroe{
    private alterEgo:string; //visible solo dentro de la clase
    public edad:number;//visible fuera de la clase
    static nombreReal:string; //puede acceder al valor de la propiedad, sin tener que hacer una instancia
    
    imprimirnombre(){ //metodo
        return this.alterEgo;
    }

    constructor ( alterEgo: string){
        this.alterEgo=alterEgo
    }
} */

//Metodo 2, mejor usar este
class PersonaNormal{
    constructor(
        public nombre: string,
        public direccion: string ){
        }
}



class Heroe extends PersonaNormal{
    constructor ( 
        public alterEgo:string,
        public edad:number,
        public nombreReal:string){
            super(nombreReal,"NYC");
        }
}

//crear una instancia -para las variables que no se pueden ver por defecto/static - (public)
const ironman= new Heroe("Ironman",45,"Tony");


