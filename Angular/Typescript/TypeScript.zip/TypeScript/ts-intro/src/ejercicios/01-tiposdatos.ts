



/*
    ===== Código de TypeScript =====
*/

let nombre:string = 'Nicole'; /* definir variable*/
let hp: number | string= 95; 
const na="chaves"; /* definir constante, no tiene tipo, no se puede cambiar*/

nombre="Fernando";/* al ya definirla como un string en general no me deja ponerle un dato numerico, 
en el caso de hp si, y es por el or*/


console.log(nombre,hp, na);