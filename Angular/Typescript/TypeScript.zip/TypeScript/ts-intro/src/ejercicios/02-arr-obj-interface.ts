/**** Arreglos ****/
let habilidades=[]  /* Me permite poner cualquier tipo de dato, tipo any, pero queremos evitar esto 
siendo mas estructurados  */
let habilidades1: (boolean|number)[]=[100, true] /* Arreglocon 2 tipos de datos */
habilidades1.push(false)

/**** Objetos ****/

interface personaje{ /* Establece como debe ser un objeto */
    nombre: string,
    hp:number,
    habilidades: string [], /* tipo string o objeto */
    puebloNatal?: string /* caract opcional */
} const personaje: personaje ={
    nombre:"Strider",
    hp:100,
    habilidades: ["Bash","count"]
}

personaje.puebloNatal= "Pueblo Paleta";

console.table(personaje);
